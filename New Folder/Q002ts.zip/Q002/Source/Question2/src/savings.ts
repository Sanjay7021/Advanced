import { AccountData } from "./main";

let Accountdata: any = localStorage.getItem('data')
let details: AccountData
if (Accountdata) {
    details = JSON.parse(Accountdata);
    $(document).ready(() => {
        console.log(details);
        let option = ($("#customerSelect")).change(() => {
            $("#select").attr("disabled", "true")
            $("#savingAccName").val(details.customername)
            $("#savingAccountNumber").val(details.accountnumber)
            $("#accBalP").text(details.accountbalance)
        })
        $("<option></option>").val(details["customerid"]).text(details["customerid"]).appendTo(option)


        let x: string = "abc";
        $("#checkTransaction").click(() => {
            let Amount = $("#amount").val()
            if (Amount) {
                console.log(x);
                $("#amountErr").text("")

                if (x == "Withdraw") {
                    if (details.accountbalance < Number(Amount)) {
                        $("#accountFundError").text("Insufficient funds")
                    }
                    else {
                        details.accountbalance -= Number(Amount)
                        $("#accBalP").text(details.accountbalance)
                        let data = JSON.stringify(details)
                        localStorage.setItem("data", data)
                    }
                }
                else if (x == "Deposit") {
                    details.accountbalance += Number(Amount)
                    $("#accBalP").text(details.accountbalance)
                    let data = JSON.stringify(details)
                    localStorage.setItem("data", data)

                }
            }
            else {
                $("#amountErr").text("Please mention amount for transaction")
            }
            if (x != "Withdraw" && x != "Deposit") {
                $("#transactionErr").text("Please select one option")
            }
            else {
                $("#transactionErr").text("")
            }


        })
        $("#withdrawRadio").on("click", () => {
            x = "Withdraw"
        })
        $("#depositRadio").on("click", () => {
            x = "Deposit"
        })

    })

}


