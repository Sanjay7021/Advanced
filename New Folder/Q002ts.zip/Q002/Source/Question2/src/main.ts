export interface AccountData {
  customerid: number;
  accountnumber: number;
  customername: string;
  accountbalance: number;
}



function Alphabet(x: any) {
  x = x.toLowerCase()
  for (let i of x) {
    if (i >= "a" && i <= "z") {
      return true
    }
  }
}

function checkNumber(x: any) {
  for (let i of x) {
    if (i >= 0 && i <= 9) {
      return true
    }
  }
}



$(document).ready(() => {
  let customerID = $("#customerID").val()
  let accountNumber = $("#accNum").val()
  let customerName = $("#customerName").val()
  let accountBalance = $("#accBal").val()

  let data: AccountData;

  $("#customerForm").click(() => {

    customerID = $("#customerID").val()
    accountNumber = $("#accNum").val()
    customerName = $("#customerName").val()
    accountBalance = $("#accBal").val()
    if (typeof (customerName) == "string") {
      data = {
        "customerid": Number(customerID),
        "accountnumber": Number(accountNumber),
        "customername": customerName,
        "accountbalance": Number(accountBalance)
      }
    }



    let num = Number(customerID)
    if ($("#customerID").val() == "") {
      $("#IDerr").text("Please enter Customer ID")
    }
    else if (Alphabet(customerID)) {
      $("#IDerr").text("Invalid customer ID. Please enter a valid number.")
    }

    else if (Number.isNaN(num)) {
      $("#IDerr").text("Invalid customer ID. Please enter a valid number.")

    }
    if ($("#accNum").val() == "") {
      $("#accErr").text("Please enter Account Number")
    }

    else if (Alphabet(accountNumber)) {
      $("#accErr").text("Please enter correct account Number")
    }
    else if (typeof (accountNumber) == "string") {
      if (accountNumber.length != 14) {
        $("#accErr").text("Please enter correct account Number")
      }
    }
    if ($("#customerName").val() == "") {
      $("#NameErr").text("Please enter Customer name")
    }
    else if (checkNumber(customerName)) {
      $("#NameErr").text("Invalid customer name. Name should not contain spaces at the left or right.")
    }
    if ($("#accBal").val() == "") {
      $("#balErr").text("Please enter Account Balance")
    }
    else if (Number($("#accBal").val()) < 5000) {
      $("#balErr").text("Amount should be minimum 5000")
    }
    else if (Alphabet(accountBalance)) {
      $("#balErr").text("Please enter only number")
    }

  })

  $("#redirect").on("click", () => {
    window.location.href += "SavingAccountForm.html"
    localStorage.setItem("data", JSON.stringify(data))

    console.log(customerID, accountNumber, customerName, accountBalance);

  })
})

