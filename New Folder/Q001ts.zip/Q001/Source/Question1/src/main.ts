interface Mobike {
  bno: string,
  phno: number,
  name: string,
  days: number,
  charge: number
}

class Mobike implements Mobike {
  constructor(bno: any, phno: any, name: any, days: any) {
    this.bno = bno,
      this.phno = phno,
      this.name = name,
      this.days = days,
      this.charge = this.compute()
  }
  compute(): number {
    let day = this.days
    if (day <= 10) {
      return 900 * day
    }
    else if (day <= 20) {
      return 900 * 10 + 700 * (day - 10)
    }
    else {
      return 900 * 10 + 700 * 10 + (100 * (day - 20))
    }


  }
  display(): object[] {
    let array = [{ "Bike No.": this.bno }, { "PhoneNo": this.phno }, { "No. of days": this.days }, { "Charge": this.charge }]
    return array
  }
}
$("document").ready(() => {
  $("#btnCompute").click(() => {
    let error: number = 0


    if ($("#bno").val() == "") {
      $("#errorbno").text("bno can not be blank.")
    }
    else {
      $("#errorbno").text("")
      error = error + 1


    }
    if ($("#phno").val() == "") {
      $("#errorphno").text("phno can not be blank.")
    }
    else {
      $("#errorphno").text("")
      error = error + 1

    }
    if ($("#name").val() == "") {
      $("#errorname").text("name can not be blank.")
    }
    else {
      $("#errorname").text("")
      error = error + 1


    }
    if ($("#days").val() == "") {
      $("#errordays").text("days can not be blank.")
    }
    else {
      $("#errordays").text("")
      error = error + 1

    }
    let bno = document.getElementById("bno") as HTMLInputElement
    let phno = document.getElementById("phno") as HTMLInputElement
    let name = document.getElementById("name") as HTMLInputElement
    let days = document.getElementById("days") as HTMLInputElement

    let bnoNew = bno.value
    let phnoNew = Number(phno.value)
    let nameNew = name.value
    let daysNew = Number(days.value)

    let data = new Mobike(bnoNew, phnoNew, nameNew, daysNew)
    console.log(data);


    let row = $("<tr></tr>").appendTo($("#result"))
    $("<td></td>").text(data.bno).appendTo(row)
    $("<td></td>").text(data.phno).appendTo(row)
    $("<td></td>").text(data.days).appendTo(row)
    $("<td></td>").text(data.charge).appendTo(row)
  })
})