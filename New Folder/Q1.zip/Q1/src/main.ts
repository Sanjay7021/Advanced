import { data } from "./data.json";
import { PassengerDetail } from "./Passenger";

console.log(data);


$(document).ready(function () {

  // let arr = []

  for (let i = 0; i < data.length; i++) {
    let passenger = new PassengerDetail(Number(data[i].ID), String(data[i].Name), String(data[i].Address), String(data[i].State), String(data[i].City));

    let p = new Map();
    p.set(data[i].ID, data[i])
    console.log(p);




    let tr = $("<tr></tr>").attr("id", `passenger${data[i].ID}`)
    $("<td></td>").text(data[i].ID).appendTo($(tr))
    $("<td></td>").text(data[i].Name).appendTo($(tr))
    $("<td></td>").text(data[i].Address).appendTo($(tr))
    $("<td></td>").text(data[i].State).appendTo($(tr))
    $("<td></td>").text(data[i].City).appendTo($(tr))
    $("table").append($(tr));

  }

  $("#search").click(function () {
    for (let i = 0; i < data.length; i++) {
      if (data[i].ID == $("#searchInput").val()) {
        $("tbody").html("")
        let tr = $("<tr></tr>").attr("ID", `passenger${data[i].ID}`)
        $("<td></td>").text(data[i].ID).appendTo($(tr))
        $("<td></td>").text(data[i].Name).appendTo($(tr))
        $("<td></td>").text(data[i].Address).appendTo($(tr))
        $("<td></td>").text(data[i].State).appendTo($(tr))
        $("<td></td>").text(data[i].City).appendTo($(tr))
        $("table").append($(tr));
      }
      else {
        $("tbody").html("")
      }
    }
  })
})



