interface fields {
    id: number
    name: string
    address: string
    state: string
    city: string
}

export class PassengerDetail implements fields {
    id: number
    name: string
    address: string
    state: string
    city: string
    set: any

    constructor(id: number,
        name: string,
        address: string,
        state: string,
        city: string,) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.state = state;
        this.city = city;
    }


}
