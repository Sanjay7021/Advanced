// import $ from 'jquery';
type cdetails = { cno: "", phno: number, name: "" }


class Customer {
  cno: string;
  phno: number;
  name: string;
  ticketCost: number;

  constructor(cno: string, phno: number, name: string) {
    this.cno = cno;
    this.phno = phno;
    this.name = name;
    this.ticketCost = 0;
  }

  display(): object {
    let newobj = { cno: "", phno: Number(), name: "" }
    console.log("yes");

    newobj.cno = this.cno;
    newobj.phno = this.phno;
    newobj.name = this.name;
    return newobj;
  }

  compute(n: number): number {

    this.ticketCost = n;
    let computedcost: number = 0;
    if (this.ticketCost > 70000) {
      computedcost = this.ticketCost - ((this.ticketCost * 18) / 100);
    } else if (this.ticketCost >= 55001 && this.ticketCost <= 70000) {
      computedcost = this.ticketCost - ((this.ticketCost * 16) / 100);
    } else if (this.ticketCost >= 35001 && this.ticketCost <= 55000) {
      computedcost = this.ticketCost - ((this.ticketCost * 12) / 100);
    } else if (this.ticketCost >= 25001 && this.ticketCost <= 35000) {
      computedcost = this.ticketCost - ((this.ticketCost * 10) / 100);
    } else if (this.ticketCost <= 25000) {
      computedcost = this.ticketCost - ((this.ticketCost * 2) / 100);
    }

    return computedcost;
  }
}

$("#home").on("click", function () {
  window.location.href = "index.html"
})
$("#customerForm").on("click", function () {
  window.location.href = "customerForm.html"
})
$("#ticketForm").on("click", function () {
  window.location.href = "ticketForm.html"
})


let cdata = localStorage.getItem("cdata");
let data = JSON.parse(cdata);


//for customer add 
$("#addCustomerFormBtn").on("click", function () {
  let cno = String($("#customerNo").val());
  let phno = Number($("#customerPhNo").val());
  let name = String($("#customerName").val());
  let temp: Boolean = true;

  console.log(cno.length);


  if (cno.length == 0) {
    $("#customerNumberError").text("Customer Number Required");
    temp = false;
  }
  else {
    $("#customerNumberError").text(" ");
  }



  if (data != null) {
    for (let x of data) {
      if (x.cno == cno) {
        temp = false;
        $("#customerNumberError").text("Customer Number Already Present");
      }
    }
  } else {
    data = [];
  }


  if (String(phno).length == 1) {
    temp = false;
    $("#customerPhNoError").text("Phone Number Required");
  } else if (String(phno).length > 0 && String(phno).length < 10) {
    temp = false;
    $("#customerPhNoError").text("Phone Number length must be 10");
  } else {
    $("#customerPhNoError").text(" ");
  }



  if (name.length == 0) {
    temp = false;
    $("#customerNameError").text("Customer Name Required");
  } else if (name.length < 3 || name.length > 10) {
    temp = false;
    $("#customerNameError").text("Customer Name length should at least 3 character and at most 10 character");
  } else {
    $("#customerNameError").text("");
  }


  let resulto: object;

  //for add in to local storage
  if (temp == true) {

    let obj = new Customer(cno, phno, name);
    resulto = obj.display();
    data.push(resulto);
    let sd = JSON.stringify(data)

    localStorage.setItem("cdata", sd);
    $("p").html("");

    localStorage.setItem(cno, JSON.stringify([]))

    window.location.href = 'index.html';
    $("#customer").trigger("reset");
  }

  tabledisplay();

})

//for drop down
for (let x of data) {
  $(`<option value=${x.cno}></option>`).text(x.cno).appendTo($("#customerNumber"));
}

//for add history in local 
$("#ticketFormSubmitBtn").on("click", function () {
  let cno = String($("#customerNumber").val());
  let ticketCost = Number($("#ticketCost").val());
  let temp: boolean = true;

  if (cno == "0") {
    temp = false;
    $("#customerNumberDropDownError").text("Select customer Number")
  } else {
    $("#customerNumberDropDownError").text("");
  }

  if (ticketCost == 0) {
    temp = false;
    $("#ticketCostError").text("Ticket Cost Required");
  } else if (ticketCost < 0) {
    temp = false;
    $("#ticketCostError").text("Ticket Cost must be postive");
  } else {
    $("#ticketCostError").text("");
  }



  if (temp == true) {
    let a = { ticketcost: Number(), tickercomputecost: Number() }
    a.ticketcost = ticketCost;


    for (let x of data) {
      if (x.cno == cno) {
        let obj = new Customer(x.cno, x.phno, x.name);
        a.tickercomputecost = obj.compute(ticketCost);
        $("p").html("");
      }
    }


    const result = localStorage.getItem(cno);
    let tdata = JSON.parse(result);
    tdata.push(a);

    localStorage.setItem(cno, JSON.stringify(tdata))

    window.location.href = 'index.html';
    $("#ticket").trigger("reset");
    tabledisplay();
  }



})



//for home page table 
function tabledisplay() {
  for (let x of data) {
    let tr = $("<tr></tr>")
    $("<td></td>").text(x.cno).appendTo(tr);
    $("<td></td>").text(x.phno).appendTo(tr);
    $("<td></td>").text(x.name).appendTo(tr);
    let td = $("<td></td>");
    let tb = $(`<table id="nestedTable-${x.cno}" border = "1"></table>`);
    $("<tr></tr>").html("<th>Ticket Cost</th><th>Ticket Computed Cost</th>").appendTo(tb);
    const result = localStorage.getItem(x.cno);
    const entry = JSON.parse(result);


    for (let i of entry) {
      let tr = $("<tr></tr>");
      $("<td></td>").text(i.ticketcost).appendTo(tr);
      $("<td></td>").text(i.tickercomputecost).appendTo(tr);
      $(tr).appendTo(tb);
    }
    $(tb).appendTo(td);
    $(td).appendTo(tr);
    $(tr).appendTo("#main");
  }
}
tabledisplay();